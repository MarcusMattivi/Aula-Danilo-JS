const varGlobal = 'Essa é uma variável global!'

function mostrarConsoloe() {
    let varLocal = "Essa é uma variável local!"

    console.log(varGlobal)
    console.log(varLocal)
}
mostrarConsoloe()