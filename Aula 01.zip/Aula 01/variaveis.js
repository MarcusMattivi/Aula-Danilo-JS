/* Bloco do Var
var nome = "Marcus" // Declarano a variável
console.log(nome)

var nome = "Cuchinski" // Recriando a variável
console.log(nome)

nome = "Marcus Cuchinski" // Reatribuindo valor
console.log(nome)*/

/* Bloco do Let*/
/*
function getNome() {
let nome = 'Bia'

if (nome === 'Bia') {
    let nome = 'Bia Becker'

    console.log('Dentro do if: ' + nome)
}
console.log('Fora do if: ' + nome)
}
getNome()
*/

/* Bloco Const
const nome = "Bia"
console.log(nome)
const nome = "Becker" //Tentativa de criar outra com o mesmo nome
conseole.log(nome)
 nome = "Becker" //Tentativa de Sobescrever
console.log(nome)
*/
